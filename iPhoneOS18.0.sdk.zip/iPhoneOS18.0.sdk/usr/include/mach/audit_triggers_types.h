typedef const char* string_t;
